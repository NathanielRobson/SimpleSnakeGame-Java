public class Main {

    //main method to run game
    public static void main(String[] args) {
        GameView gv = new GameView();

        gv.initialize();

    }
}
