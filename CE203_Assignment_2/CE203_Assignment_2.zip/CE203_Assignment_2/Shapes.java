public enum Shapes {
    SnakeHead,

    SnakeBody,

    Apple,

    Obstacle

}

//These are the different Objects drawn in my game, this is to allow
// me to easily select from an enumeration when wanting to draw the shape on the
//grid